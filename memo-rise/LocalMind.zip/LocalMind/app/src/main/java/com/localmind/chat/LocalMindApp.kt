package com.localmind.chat

import android.app.Application
import com.google.firebase.FirebaseApp
import com.google.firebase.appcheck.FirebaseAppCheck
import com.google.firebase.appcheck.debug.DebugAppCheckProviderFactory
import com.google.firebase.appcheck.playintegrity.PlayIntegrityAppCheckProviderFactory
import com.localmind.chat.data.repo.RetentionWorker

class LocalMindApp : Application() {

    override fun onCreate() {
        super.onCreate()
        FirebaseApp.initializeApp(this)

        // App Check stops someone lifting your config out of the APK and billing your
        // Gemini quota to their own app. Without it, a client-side AI key is wide open.
        FirebaseAppCheck.getInstance().installAppCheckProviderFactory(
            if (BuildConfig.DEBUG) {
                // Prints a debug token to logcat. Register it in the Firebase console
                // under App Check > Apps > Manage debug tokens.
                DebugAppCheckProviderFactory.getInstance()
            } else {
                PlayIntegrityAppCheckProviderFactory.getInstance()
            }
        )

        // Idempotent: enqueueUniquePeriodicWork with KEEP means calling this on
        // every cold start is safe and does not reset the schedule.
        RetentionWorker.schedule(this)
    }
}
