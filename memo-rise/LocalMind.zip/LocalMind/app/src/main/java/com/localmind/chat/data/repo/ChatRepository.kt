package com.localmind.chat.data.repo

import android.content.Context
import com.localmind.chat.ai.AiEngine
import com.localmind.chat.ai.Chunk
import com.localmind.chat.ai.MemoryExtractor
import com.localmind.chat.ai.PromptBuilder
import com.localmind.chat.data.cloud.CloudStore
import com.localmind.chat.data.local.ConversationEntity
import com.localmind.chat.data.local.LocalDatabase
import com.localmind.chat.data.local.MemoryEntity
import com.localmind.chat.data.local.MessageEntity
import com.localmind.chat.data.local.Role
import com.localmind.chat.data.local.SyncState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Local-first. Every message is committed to the encrypted database before anything
 * is sent anywhere, so the UI is driven entirely off Room and the chat survives being
 * killed mid-reply. Cloud work happens afterwards, is best-effort, and is limited to
 * whatever SyncPolicy approves.
 */
class ChatRepository(
    context: Context,
    private val ai: AiEngine = AiEngine(),
    private val extractor: MemoryExtractor = MemoryExtractor(),
    private val cloud: CloudStore = CloudStore()
) {

    private val db = LocalDatabase.get(context)
    private val messages = db.messages()
    private val memories = db.memories()
    private val conversations = db.conversations()

    /** Background work that must outlive the screen (extraction, uploads). */
    private val background = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private var persona: String = PromptBuilder.DEFAULT_PERSONA

    fun observeMessages(conversationId: String): Flow<List<MessageEntity>> =
        messages.observeConversation(conversationId)

    fun observeMemories(): Flow<List<MemoryEntity>> = memories.observeActive()

    fun observeMessageCount(): Flow<Int> = messages.observeCount()

    suspend fun activeConversation(): ConversationEntity = withContext(Dispatchers.IO) {
        conversations.mostRecent() ?: ConversationEntity(title = "New chat").also {
            conversations.upsert(it)
        }
    }

    /**
     * Writes the user turn, streams the reply into a placeholder row, then kicks off
     * extraction. Emits nothing: the UI is already observing Room, so the stream shows
     * up through the database rather than through a second channel.
     */
    suspend fun send(conversationId: String, userText: String) = withContext(Dispatchers.IO) {
        val trimmed = userText.trim()
        if (trimmed.isEmpty()) return@withContext

        val userMessage = MessageEntity(
            conversationId = conversationId,
            role = Role.USER,
            text = trimmed
        )
        messages.insert(userMessage)
        conversations.touch(conversationId)

        // Build history BEFORE inserting the placeholder, so the empty assistant row
        // never becomes model context.
        val history = messages.recentForContext(conversationId, CONTEXT_TURNS)
            .asReversed()
            .filter { it.id != userMessage.id }

        val promptMemories = memories.topForPrompt(MEMORIES_IN_PROMPT)
        val systemInstruction = PromptBuilder.build(persona, promptMemories)
        if (promptMemories.isNotEmpty()) {
            memories.markUsed(promptMemories.map { it.id })
        }

        val reply = MessageEntity(
            conversationId = conversationId,
            role = Role.MODEL,
            text = "",
            streaming = true
        )
        messages.insert(reply)

        val buffer = StringBuilder()
        try {
            ai.stream(history, trimmed, systemInstruction).collect { chunk ->
                when (chunk) {
                    is Chunk.Text -> {
                        buffer.append(chunk.delta)
                        messages.updateText(reply.id, buffer.toString(), streaming = true)
                    }

                    is Chunk.Done -> {
                        messages.updateText(reply.id, buffer.toString(), streaming = false)
                        if (chunk.sources.isNotEmpty()) {
                            messages.updateSources(
                                reply.id,
                                chunk.sources.joinToString("\n") { "${it.title}\t${it.url}" }
                            )
                        }
                    }
                }
            }
        } catch (e: Exception) {
            if (buffer.isEmpty()) {
                messages.markFailed(reply.id)
            } else {
                // Partial answer is still worth keeping; just stop the spinner.
                messages.updateText(reply.id, buffer.toString(), streaming = false)
            }
        }

        titleIfNeeded(conversationId, trimmed)
        background.launch { learnFrom(trimmed, userMessage.id) }
    }

    /** Cheap local title from the first turn — no extra model call for something cosmetic. */
    private suspend fun titleIfNeeded(conversationId: String, firstText: String) {
        val existing = conversations.mostRecent() ?: return
        if (existing.id != conversationId || existing.title != "New chat") return
        conversations.rename(conversationId, firstText.take(40).trim())
    }

    /**
     * The "keeps learning" path. Facts land locally first and are only offered to the
     * cloud if SyncPolicy approves them.
     */
    private suspend fun learnFrom(userText: String, sourceMessageId: String) {
        extractor.extract(userText).forEach { fact ->
            val memory = MemoryEntity(
                text = fact.text,
                category = fact.category,
                confidence = fact.confidence,
                sourceMessageId = sourceMessageId
            )

            // Unique index on text means duplicates are silently ignored (-1).
            val inserted = memories.insertIfNew(memory)
            if (inserted == -1L) return@forEach

            if (SyncPolicy.shouldSync(memory)) {
                memories.setSyncState(memory.id, SyncState.PENDING)
                if (cloud.putMemory(memory)) {
                    memories.setSyncState(memory.id, SyncState.SYNCED)
                }
            }
        }
    }

    /** Pinning is the user's explicit "this one matters" — and the only route to the cloud. */
    suspend fun setPinned(message: MessageEntity, pinned: Boolean) = withContext(Dispatchers.IO) {
        if (!pinned) {
            messages.setPinned(message.id, false, SyncState.LOCAL_ONLY)
            cloud.deletePinnedMessage(message.id)
            return@withContext
        }

        val candidate = message.copy(pinned = true)
        if (!SyncPolicy.shouldSync(candidate)) {
            messages.setPinned(message.id, true, SyncState.LOCAL_ONLY)
            return@withContext
        }

        messages.setPinned(message.id, true, SyncState.PENDING)
        if (cloud.putPinnedMessage(candidate)) {
            messages.setSyncState(message.id, SyncState.SYNCED)
        }
    }

    suspend fun forget(memory: MemoryEntity) = withContext(Dispatchers.IO) {
        memories.revoke(memory.id)
        cloud.deleteMemory(memory.id)
    }

    /** Retries anything the gate approved but that failed to upload while offline. */
    suspend fun flushPending() = withContext(Dispatchers.IO) {
        memories.awaitingUpload().forEach {
            if (cloud.putMemory(it)) memories.setSyncState(it.id, SyncState.SYNCED)
        }
        messages.pinnedAwaitingUpload().forEach {
            if (cloud.putPinnedMessage(it)) messages.setSyncState(it.id, SyncState.SYNCED)
        }
    }

    // ---- Retention -----------------------------------------------------------

    private val settings = RetentionSettings(context)
    private val sweeper = RetentionSweeper(context, settings)

    var retentionDays: Int
        get() = settings.days
        set(value) {
            settings.days = value
        }

    var retentionDisclosed: Boolean
        get() = settings.disclosureShown
        set(value) {
            settings.disclosureShown = value
        }

    /**
     * Live count of messages the next sweep will remove.
     *
     * The cutoff is captured once per collection rather than recomputed continuously —
     * a window that slid on every emission would make the number flicker for no
     * benefit, since the sweep itself only runs daily.
     */
    fun observeExpiring(): Flow<Int> {
        val cutoff = RetentionPolicy.cutoff(settings.days) ?: return flowOf(0)
        return messages.observeExpiring(cutoff)
    }

    fun databaseBytes(): Long = sweeper.databaseBytes()

    /**
     * Runs on launch so a user returning after a long gap sees retention applied
     * immediately, rather than whenever WorkManager next gets a window.
     */
    suspend fun sweepExpired(force: Boolean = false): SweepResult =
        if (!settings.disclosureShown) SweepResult.NOTHING else sweeper.sweep(force)

    /** "Clear now" from settings: sweeps and always compacts, so the effect is visible. */
    suspend fun clearOldChatsNow(): SweepResult = sweeper.sweep(force = true)

    suspend fun updatePersona(newPersona: String) = withContext(Dispatchers.IO) {
        persona = newPersona.ifBlank { PromptBuilder.DEFAULT_PERSONA }
        cloud.putProfile(persona, groundingEnabled = true)
    }

    /** Wipes the phone and the server copy. Local history cannot be recovered after this. */
    suspend fun deleteEverything() = withContext(Dispatchers.IO) {
        cloud.wipeEverything()
        messages.deleteAll()
        memories.deleteAll()
        conversations.deleteAll()
    }

    private companion object {
        /** Turns of history sent to the model. Trades cost against how far back it recalls. */
        const val CONTEXT_TURNS = 24
        const val MEMORIES_IN_PROMPT = 40
    }
}
