package com.localmind.chat.data.repo

import com.localmind.chat.data.local.MemoryEntity
import com.localmind.chat.data.local.MessageEntity

/**
 * The one and only gate for outbound data.
 *
 * Every write to Firestore in this app goes through a check here. Keeping the rules in
 * a single object means the answer to "what does this app upload?" is auditable by
 * reading one file, rather than by grepping the codebase for Firestore calls.
 *
 * What is NEVER uploaded:
 *   - raw conversation transcripts
 *   - unpinned messages, of either role
 *   - the local database passphrase
 *   - draft text, or anything typed but not sent
 *
 * What IS uploaded:
 *   - messages the user explicitly pinned
 *   - high-confidence durable facts in an allowed category
 *   - the persona and app settings, so a new device behaves the same
 */
object SyncPolicy {

    /** Facts that are worth carrying between devices. Anything else stays local. */
    private val SYNCABLE_CATEGORIES = setOf(
        "identity",     // name, pronouns, where they live
        "preference",   // tone, response length, language
        "goal",         // long-running projects and objectives
        "relationship", // who matters to them, by role
        "constraint"    // allergies, accessibility needs, hard limits
    )

    /**
     * Categories that read as sensitive even when the user volunteered them. These are
     * still useful in-session, so they live in the local store and shape the prompt,
     * but they never reach a server.
     */
    private val NEVER_SYNC_CATEGORIES = setOf(
        "health", "finance", "credentials", "location_precise", "political", "religion", "sexuality"
    )

    private const val MIN_CONFIDENCE = 0.65f

    /** Pinning is a deliberate user action, so it is the only route for message text. */
    fun shouldSync(message: MessageEntity): Boolean =
        message.pinned && !message.streaming && !message.failed && message.text.isNotBlank()

    fun shouldSync(memory: MemoryEntity): Boolean {
        if (memory.revoked) return false
        if (memory.confidence < MIN_CONFIDENCE) return false
        val category = memory.category.lowercase()
        if (category in NEVER_SYNC_CATEGORIES) return false
        return category in SYNCABLE_CATEGORIES
    }

    /** Shown in the privacy screen so the user can see the rule, not just trust it. */
    fun explain(memory: MemoryEntity): String = when {
        memory.revoked -> "Removed by you. Not used, not synced."
        memory.category.lowercase() in NEVER_SYNC_CATEGORIES ->
            "Sensitive category. Stays on this phone."
        memory.confidence < MIN_CONFIDENCE -> "Not confident enough yet. Stays on this phone."
        memory.category.lowercase() !in SYNCABLE_CATEGORIES ->
            "Category isn't backed up. Stays on this phone."
        else -> "Backed up so your other devices know this too."
    }
}
