package com.localmind.chat.data.cloud

import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.firestore
import com.localmind.chat.data.local.MemoryEntity
import com.localmind.chat.data.local.MessageEntity
import kotlinx.coroutines.tasks.await

/**
 * The app's entire cloud surface.
 *
 * There is deliberately no method here that can write a conversation or a batch of
 * messages. The absence is the design: even a future bug in the repository cannot
 * upload a transcript, because no code path exists to do it.
 *
 * Firestore layout:
 *   users/{uid}
 *     profile          -> persona + settings                  (1 doc)
 *     memories/{id}    -> durable facts that passed the gate
 *     pinned/{id}      -> messages the user explicitly pinned
 */
class CloudStore {

    private val db = Firebase.firestore
    private val auth: FirebaseAuth = Firebase.auth

    /**
     * Anonymous auth gives each install a stable uid with no signup friction, which
     * keeps the security rules meaningful. Link it to a real credential later with
     * FirebaseAuth.linkWithCredential to survive reinstalls.
     */
    suspend fun uid(): String? = try {
        (auth.currentUser ?: auth.signInAnonymously().await().user)?.uid
    } catch (e: Exception) {
        null // offline: callers leave rows PENDING and retry later
    }

    private suspend fun user() = uid()?.let { db.collection("users").document(it) }

    suspend fun putMemory(memory: MemoryEntity): Boolean {
        val doc = user()?.collection("memories")?.document(memory.id) ?: return false
        return runCatching {
            doc.set(
                mapOf(
                    "text" to memory.text,
                    "category" to memory.category,
                    "confidence" to memory.confidence,
                    "createdAt" to memory.createdAt,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        }.isSuccess
    }

    suspend fun deleteMemory(id: String): Boolean {
        val doc = user()?.collection("memories")?.document(id) ?: return false
        return runCatching { doc.delete().await() }.isSuccess
    }

    suspend fun putPinnedMessage(message: MessageEntity): Boolean {
        val doc = user()?.collection("pinned")?.document(message.id) ?: return false
        return runCatching {
            doc.set(
                mapOf(
                    "text" to message.text,
                    "role" to message.role.name,
                    "createdAt" to message.createdAt,
                    "sources" to message.sources,
                    "pinnedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        }.isSuccess
    }

    suspend fun deletePinnedMessage(id: String): Boolean {
        val doc = user()?.collection("pinned")?.document(id) ?: return false
        return runCatching { doc.delete().await() }.isSuccess
    }

    suspend fun putProfile(persona: String, groundingEnabled: Boolean): Boolean {
        val doc = user() ?: return false
        return runCatching {
            doc.set(
                mapOf(
                    "persona" to persona,
                    "groundingEnabled" to groundingEnabled,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        }.isSuccess
    }

    /** Restores the synced slice onto a fresh install. Chat history is not restorable. */
    suspend fun fetchMemories(): List<Triple<String, String, Float>> {
        val collection = user()?.collection("memories") ?: return emptyList()
        return runCatching {
            collection.get().await().documents.mapNotNull { doc ->
                val text = doc.getString("text") ?: return@mapNotNull null
                Triple(
                    doc.id,
                    text,
                    doc.getDouble("confidence")?.toFloat() ?: 0.5f
                )
            }
        }.getOrDefault(emptyList())
    }

    /** Right-to-erasure: removes everything this app ever put on a server. */
    suspend fun wipeEverything(): Boolean {
        val doc = user() ?: return false
        return runCatching {
            listOf("memories", "pinned").forEach { name ->
                doc.collection(name).get().await().documents.forEach { it.reference.delete().await() }
            }
            doc.delete().await()
        }.isSuccess
    }
}
