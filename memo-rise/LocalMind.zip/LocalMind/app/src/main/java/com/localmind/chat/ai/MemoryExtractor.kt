package com.localmind.chat.ai

import android.util.Log
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.GenerativeBackend
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.generationConfig
import com.localmind.chat.BuildConfig
import org.json.JSONObject

data class ExtractedFact(
    val text: String,
    val category: String,
    val confidence: Float
)

/**
 * Runs a small, cheap model over a single user turn and pulls out durable facts.
 *
 * Runs after the reply has already been shown, so it never adds latency to the chat.
 * Uses a smaller model than the conversation on purpose: extraction is a narrow
 * classification job and doesn't need the flagship.
 */
class MemoryExtractor {

    private val model = Firebase.ai(backend = GenerativeBackend.googleAI()).generativeModel(
        modelName = BuildConfig.EXTRACTOR_MODEL,
        generationConfig = generationConfig {
            temperature = 0f // extraction should be repeatable, not creative
            responseMimeType = "application/json"
            maxOutputTokens = 512
        },
        systemInstruction = content { text(PromptBuilder.EXTRACTOR_INSTRUCTION) }
    )

    suspend fun extract(userText: String): List<ExtractedFact> {
        if (userText.length < 12) return emptyList() // "ok", "thanks", "lol"

        return try {
            val raw = model.generateContent(
                content { text("Chat turn from the user:\n\n$userText") }
            ).text.orEmpty()
            parse(raw)
        } catch (e: Exception) {
            // Extraction is best-effort enrichment. A failure must never surface to the
            // user or interrupt the conversation.
            Log.w(TAG, "Extraction failed", e)
            emptyList()
        }
    }

    /** Lenient on purpose: a stray fence or trailing comma shouldn't cost us the batch. */
    private fun parse(raw: String): List<ExtractedFact> {
        val json = raw.substringAfter("```json", raw)
            .substringBefore("```")
            .trim()
            .ifEmpty { return emptyList() }

        val start = json.indexOf('{')
        val end = json.lastIndexOf('}')
        if (start == -1 || end <= start) return emptyList()

        val facts = JSONObject(json.substring(start, end + 1)).optJSONArray("facts")
            ?: return emptyList()

        return (0 until facts.length()).mapNotNull { index ->
            val item = facts.optJSONObject(index) ?: return@mapNotNull null
            val text = item.optString("text").trim()
            if (text.isEmpty() || text.length > 140) return@mapNotNull null

            ExtractedFact(
                text = text,
                category = item.optString("category", "other").trim().lowercase(),
                confidence = item.optDouble("confidence", 0.0).toFloat().coerceIn(0f, 1f)
            )
        }.take(MAX_PER_TURN)
    }

    private companion object {
        const val TAG = "MemoryExtractor"

        /** A single turn yielding more than this is a sign the model is padding. */
        const val MAX_PER_TURN = 4
    }
}
