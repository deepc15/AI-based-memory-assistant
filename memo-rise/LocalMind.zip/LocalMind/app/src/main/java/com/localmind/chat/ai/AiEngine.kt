package com.localmind.chat.ai

import com.google.firebase.Firebase
import com.google.firebase.ai.GenerativeModel
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.GenerateContentResponse
import com.google.firebase.ai.type.GenerativeBackend
import com.google.firebase.ai.type.Tool
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.generationConfig
import com.localmind.chat.BuildConfig
import com.localmind.chat.data.local.MessageEntity
import com.localmind.chat.data.local.Role
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

/** A web page the model consulted while answering. */
data class Source(val title: String, val url: String)

sealed interface Chunk {
    /** A piece of text to append to the visible reply. */
    data class Text(val delta: String) : Chunk

    /** Emitted once at the end, after grounding metadata has settled. */
    data class Done(val sources: List<Source>) : Chunk
}

/**
 * Wraps Firebase AI Logic. Two things make the replies feel current rather than
 * frozen at the model's training cutoff:
 *
 *  1. Tool.googleSearch() lets the model pull live web results per turn.
 *  2. The system instruction is rebuilt on every request from local memory and the
 *     real current time, so context is never stale.
 */
class AiEngine {

    private val backend = GenerativeBackend.googleAI()

    private fun chatModel(systemInstruction: String): GenerativeModel =
        Firebase.ai(backend = backend).generativeModel(
            modelName = BuildConfig.CHAT_MODEL,
            generationConfig = generationConfig {
                // Higher temperature reads as more human; drop toward 0.3 if you need
                // the assistant to be consistent rather than lively.
                temperature = 0.9f
                topP = 0.95f
                maxOutputTokens = 2048
            },
            // Grounding with Google Search. Requires Firebase Android BoM 34.0.0+.
            // Displaying grounded results carries usage requirements from the provider —
            // see the note in README before shipping.
            tools = listOf(Tool.googleSearch()),
            systemInstruction = content { text(systemInstruction) }
        )

    /**
     * Streams a reply. History is passed explicitly so the caller stays in control of
     * exactly which local rows become model context.
     */
    fun stream(
        history: List<MessageEntity>,
        userText: String,
        systemInstruction: String
    ): Flow<Chunk> = flow {
        val chat = chatModel(systemInstruction).startChat(
            history = history.map { message ->
                content(role = if (message.role == Role.USER) "user" else "model") {
                    text(message.text)
                }
            }
        )

        val sources = LinkedHashMap<String, Source>()

        chat.sendMessageStream(content(role = "user") { text(userText) })
            .collect { response ->
                response.text?.takeIf { it.isNotEmpty() }?.let { emit(Chunk.Text(it)) }
                collectSources(response, sources)
            }

        emit(Chunk.Done(sources.values.toList()))
    }

    /**
     * Grounding metadata arrives on whichever chunks the backend attaches it to, so
     * accumulate across the stream and de-duplicate by URL.
     */
    private fun collectSources(
        response: GenerateContentResponse,
        into: MutableMap<String, Source>
    ) {
        val chunks = response.candidates.firstOrNull()
            ?.groundingMetadata
            ?.groundingChunks
            ?: return

        for (chunk in chunks) {
            val web = chunk.web ?: continue
            val url = web.uri ?: continue
            val title = web.title ?: web.domain ?: url
            into.putIfAbsent(url, Source(title = title, url = url))
        }
    }
}
